
<style>
    .fa
    {
    color:#000;
    }
.tabs-bordered .tab-container{
    background: #fff;
}
</style>

<div style="background:#f2f2f2">
        <div class="container" >
            <div class="col-md-12">
                 <div class="row">
                        <div id="faq" class="page-header">
			<h2>FAQ</h2>
                        <br>
			<p>Got an idea about how we can improve? Let us know at
			<a href="#">suggestions@thewashbox.in</a></p>
			<p>If you have a question about an existing order, please email
			 <a href="#">customercare@thewashbox.in</a></p>
		      </div>
                </div>
                <div class="row">
                    <div class="tabs tabs-bordered clearfix" id="tabs">

	               <ul class="tab-nav clearfix">
                            <li><a href="#tab-1">Your first order!</a></li>
                            <li><a href="#tab-2">Dry Cleaning</a></li>
			     <li><a href="#tab-3">Wash Dry Fold Orders</a></li>
			     <li><a href="#tab-4">Payment/Feedback</a></li>
                            <li><a href="#tab-5">Collection & Delivery</a></li>
                            <li><a href="#tab-6">Account/Technical issues</a></li>
                            
                      </ul>

	             <div class="tab-container">

                         <div class="tab-content clearfix" id="tab-1">
			     <div class="panel panel-default panel-faq">
                                        <div class="panel-heading">
                                            <a href="#faq-cat-1-sub-1" data-parent="#accordion-cat-1" data-toggle="collapse" class="collapsed" aria-expanded="false">
                                                 <h4 class="panel-title">
                                                   How do I sign up?
                                                   <span class="pull-right">
                                                        <i class="fa fa-fw fa-plus-square"></i>
                                                    </span>
                                                 </h4>
                                            </a>
                                        </div>
                                        <div id="faq-cat-1-sub-1" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                            <div class="panel-body">
                                             Sign Up's / Login are hassle free with theWashBox. We avoid that pain stacking process. Just like our service at single click, now you can sign up at just single click using your Google or Facebook accounts.
                                                <br>
                                                <br>
                                              If you don't have facebook or Google account,you can create your own account.
                                            </div>
                                        </div>
                                    </div>
		                     <div class="panel panel-default panel-faq">
                                        <div class="panel-heading">
                                            <a href="#faq-cat-1-sub-2" data-parent="#accordion-cat-1" data-toggle="collapse" class="collapsed" aria-expanded="false">
                                                 <h4 class="panel-title">
                                                    What should I prepare for the first pickup?
                                                   <span class="pull-right">
                                                        <i class="fa fa-fw fa-plus-square"></i>
                                                    </span>
                                                 </h4>
                                            </a>
                                        </div>
                                        <div id="faq-cat-1-sub-2" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                            <div class="panel-body">
                                               Just have your clothes ready! Your theWashBox Agent will bring a theWashBox bag to place your loose clothes in, so it helps to have them all together.
                                                <br>
                                                <br>
                                               If you�re ordering a Wash, Tumble Dry & Fold then your theWashBox Agent will leave you with a reusable bag upon delivery, so you can collect clothes together for future orders.
                                            </div>
                                        </div>
                                    </div>
                                 
                           <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a class="collapsed" href="#faq-cat-1-sub-3" data-parent="#accordion-cat-1" data-toggle="collapse" aria-expanded="false">
                                        <h4 class="panel-title">
                                            Which items should be dry cleaned and which should be laundered?
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                           </span>
                                         </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-1-sub-3" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                    <div class="panel-body">
                                            Don't worry if you're unsure how your clothes should be treated � we'll check the label for you and take care of everything.
                                            <br>
                                            Please note that we cannot check care labels of items in Wash, Dry & Fold orders, so please separate dry clean and laundered items if needed.
					    <br>
					    We recommend not including shirts in Wash, Dry & Fold orders, to ensure they are pressed to a crisp finish.
                                    </div>
                                </div>
                           </div>
                           <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a class="collapsed" href="#faq-cat-1-sub-4" data-parent="#accordion-cat-1" data-toggle="collapse" aria-expanded="false">
                                       <h4 class="panel-title">
                                            Can I order by phone or email?
                                          <span class="pull-right">
                                              <i class="fa fa-fw fa-plus-square"></i>
                                          </span>
                                      </h4>
                                   </a>
                                </div>
                                <div id="faq-cat-1-sub-4" class="panel-collapse collapse" aria-expanded="false">
                                      <div class="panel-body">
                                        We think it would be the most convenient for you to order online through the website/mobile/tables.
                                      </div>
                                </div>
                           </div>
                          
                            <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                        <a class="collapsed" href="#faq-cat-1-sub-5" data-parent="#accordion-cat-1" data-toggle="collapse" aria-expanded="false">
                                            <h4 class="panel-title">
                                                    I'm not sure how my items should be cleaned. What should I do?
                                             <span class="pull-right">
                                                 <i class="fa fa-fw fa-plus-square"></i>
                                             </span>
                                          </h4>
                                       </a>
                                </div>
                                    <div id="faq-cat-1-sub-5" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                         <div class="panel-body">
                                              Don't worry, we're experts at dealing with this situation!
                                               <br>
                                               <br>
                                             We'll always do our best to make sure your clothes are handled correctly and with the utmost care. If there's any doubt or we can't find a care label, we'll get in touch with you as soon as possible.
                                         </div>
                                    </div>
                            </div>
                        <div class="panel panel-default panel-faq">
                            <div class="panel-heading">
                               <a class="collapsed" href="#faq-cat-1-sub-6" data-parent="#accordion-cat-1" data-toggle="collapse" aria-expanded="false">
                                    <h4 class="panel-title">
                                        How do I contact theWashBox team?
                                         <span class="pull-right">
                                            <i class="fa fa-fw fa-plus-square"></i>
                                         </span>
                                    </h4>
                                </a>
                            </div>
                            <div id="faq-cat-1-sub-6" class="panel-collapse collapse" aria-expanded="false">
                                <div class="panel-body">
                                    It's always great to hear from a customer. Connect us through contact us page or drop a email to connect@theWashBox.in.
                                    <br>
                                    <br>
                                    Want to say hello! Just dial our customer care number.
                                </div>
                            </div>
                        </div>
                  </div>
                   
                        <div class="tab-content clearfix" id="tab-2">
                             <div class="panel panel-default panel-faq">
                                    <div class="panel-heading">
                                            <a href="#faq-cat-2-sub-1" data-parent="#accordion-cat-1" data-toggle="collapse" class="collapsed" aria-expanded="false">
                                                 <h4 class="panel-title">
                                                    What if my clothes are damaged?
                                                   <span class="pull-right">
                                                        <i class="fa fa-fw fa-plus-square"></i>
                                                    </span>
                                                 </h4>
                                            </a>
                                        </div>
                                        <div id="faq-cat-2-sub-1" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                            <div class="panel-body">
                                                 Your clothes are in safe hands and incidents of damage are extremely rare � but we understand it's a natural point of concern. That's why we're fully insured!
                                                <br>
                                                <br>
                                               In the (very, very) rare event your item is damaged, we�ll reimburse you in accordance with our compensation policy. Please refer to the<a href="#">T&Cs</a> for more details. 
                                            </div>
                                        </div>
                                </div>
                          <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a class="collapsed" href="#faq-cat-2-sub-2" data-parent="#accordion-cat-1" data-toggle="collapse" aria-expanded="false">
                                        <h4 class="panel-title">
                                         What's this little sticker you've put on my clothes?                                                     
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                           </span>
                                         </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-2-sub-2" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                    <div class="panel-body">
                                          Sometimes we use small stickers to help us track your clothes in our facilities. We keep them discrete and it helps us out if you leave them on, but you can take them off if they bother you.
                                            <br>
                                          If you'd like us to remove them for you or if you don't want them on your clothes at all then that's not a problem. Just let us know in the special instructions when you place your order. 
                                    </div>
                                </div>
                           </div>
                           <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a class="collapsed" href="#faq-cat-2-sub-3" data-parent="#accordion-cat-1" data-toggle="collapse" aria-expanded="false">
                                        <h4 class="panel-title">
                                           Can you remove all stains? 
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                           </span>
                                         </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-2-sub-3" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                   <div class="panel-body">
				   Our teams use the very highest quality equipment and industry-leading stain removal products available-but some stains can stump even us.
				    <br>
				    <br>
				    We'll always try our best and we offer a free re-clean if you're ever dissatisfied with the quality we provide, but unfortunately we cannot guarantee to remove all stains.
				   </div>
                                </div>
                           </div>
                     </div>
			<div class="tab-content clearfix" id="tab-3">
                            <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a class="collapsed" href="#faq-cat-3-sub-1" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                        <h4 class="panel-title">
                                           Do I need to weigh my Wash, Tumble Dry & Fold bag?
                                            <span class="pull-right">
                                                <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                   </a>
                                </div>
                                <div id="faq-cat-3-sub-1" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                     <div class="panel-body">
					There's no need to weigh your bag, no. Your theWashBox Agent can often do this for you at your door and all Wash, Dry & Fold orders are weighed when they reach the facility. You�ll receive a confirmation email afterwards to let you know the final weight.
				     </div>
                                </div>
                           </div>
                            <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                <a class="collapsed" href="#faq-cat-3-sub-2" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                    <h4 class="panel-title">
                                        Are there any clothes you cannot clean in a Wash, Dry & Fold?
                                        <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                       </span>
                                    </h4>
                                </a>
                                </div>
                                <div id="faq-cat-3-sub-2" class="panel-collapse collapse" aria-expanded="false">
                                    <div class="panel-body">
                                        Please don�t add silk, leather, fur, velvet or cashmere or any dry clean only items to your Wash, Dry & Fold order as they aren�t typically suitable for machine washing or drying.
                                        <br>
                                        <br>
                                        Bedding and towelling should also be removed and ordered separately, as such large items can prevent a good quality of cleaning.
                                   </div>
                                </div>
                           </div>
                            <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                <a class="collapsed" href="#faq-cat-3-sub-3" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                    <h4 class="panel-title">
                                        .Do I need to sort my clothes into colours and whites?
                                        <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                       </span>
                                    </h4>
                                </a>
                                </div>
                                <div id="faq-cat-3-sub-3" class="panel-collapse collapse" aria-expanded="false">
                                    <div class="panel-body">
                                      Don,t worry about sorting clothes � we'll do that for you. All you need to do is make sure you don�t include dry clean items with a Wash, Tumble Dry & Fold order.

                                   </div>
                                </div>
                           </div>
                             <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                <a class="collapsed" href="#faq-cat-3-sub-4" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                    <h4 class="panel-title">
                                       What temperature do you wash the clothes at?
                                        <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                       </span>
                                    </h4>
                                </a>
                                </div>
                                <div id="faq-cat-3-sub-4" class="panel-collapse collapse" aria-expanded="false">
                                    <div class="panel-body">
                                      We process all Wash, Tumble Dry & Fold orders at a standard 30 degree temperature. 
                                   </div>
                                </div>
                           </div>
                             <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                <a class="collapsed" href="#faq-cat-3-sub-5" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                    <h4 class="panel-title">
                                     Do you dry my clothes?
                                        <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                       </span>
                                    </h4>
                                </a>
                                </div>
                                <div id="faq-cat-3-sub-5" class="panel-collapse collapse" aria-expanded="false">
                                    <div class="panel-body">
                                     Yes, all clothes in a Wash, Tumble Dry & Fold order are tumble dried at a medium heat. Please make sure your clothes are tumble dry friendly!  
                                   </div>
                                </div>
                           </div>
                             <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                <a class="collapsed" href="#faq-cat-3-sub-6" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                    <h4 class="panel-title">
                                      Do I get to keep the bag?
                                        <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                       </span>
                                    </h4>
                                </a>
                                </div>
                                <div id="faq-cat-3-sub-6" class="panel-collapse collapse" aria-expanded="false">
                                    <div class="panel-body">
                                     Yes, we'll leave you with a Wash, Tumble Dry & Fold bad when we deliver your first order back to you. We recommend using it to make your next theWashBox collection even quicker!       
                                   </div>
                                </div>
                              </div>
                           </div>
                         <div class="tab-content clearfix" id="tab-4">
                            <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a class="collapsed" href="#faq-cat-4-sub-1" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                        <h4 class="panel-title">
                                           How can I pay?
                                            <span class="pull-right">
                                                <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                   </a>
                                </div>
                                <div id="faq-cat-4-sub-1" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                     <div class="panel-body">
					we currently accept payments in cash.
					<br>
					<br>
					We don't encorage to tip our theWashbox Agent, if you wish to and all tips go directly to the Agents.
						
				     </div>
                                </div>
                           </div>
                            <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                <a class="collapsed" href="#faq-cat-4-sub-2" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                    <h4 class="panel-title">
                                        Is there a minimum order?
                                        <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                       </span>
                                    </h4>
                                </a>
                                </div>
                                <div id="faq-cat-4-sub-2" class="panel-collapse collapse" aria-expanded="false">
                                    <div class="panel-body">
                                        Yes, there is a 200/- minimum order value and any order under this amount will have collection chargers. You can use coupen codes.
                                   </div>
                                </div>
                           </div>
                            <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                <a class="collapsed" href="#faq-cat-4-sub-3" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                    <h4 class="panel-title">
                                       What's your pricing?
                                        <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                       </span>
                                    </h4>
                                </a>
                                </div>
                                <div id="faq-cat-4-sub-3" class="panel-collapse collapse" aria-expanded="false">
                                    <div class="panel-body">
                                       Visit thewashbox.in/pricing.
                                   </div>
                                </div>
                           </div>
                             <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                <a class="collapsed" href="#faq-cat-4-sub-4" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                    <h4 class="panel-title">
                                       .I have a general enquiry, how can I contact the team?
                                        <span class="pull-right">
                                             <i class="icon-expand-alt fa-lg"></i>
                                       </span>
                                    </h4>
                                </a>
                                </div>
                                <div id="faq-cat-4-sub-4" class="panel-collapse collapse" aria-expanded="false">
                                    <div class="panel-body">
                                     Thanks for getting in touch � you can reach us at <a href="#">info@thewashbox.com.</a>
				     <br>
				     <br>
					Alternatively, if you have a suggestion for how we can improve then you can reach the entire team at once at <a href="#">suggestions@thewashbox.com!</a>
                                   </div>
                                </div>
                           </div>
                             <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                <a class="collapsed" href="#faq-cat-4-sub-5" data-parent="#accordion-cat-3" data-toggle="collapse" aria-expanded="false">
                                    <h4 class="panel-title">
                                      What if I need to make a complaint?
                                        <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                       </span>
                                    </h4>
                                </a>
                                </div>
                                <div id="faq-cat-4-sub-5" class="panel-collapse collapse" aria-expanded="false">
                                    <div class="panel-body">
                                     Please contact the Customer Care team by emailing customercare@thewashbox.com. We treat all complaints with the atmost importance and as an opportunity to improve the quality of our service.  
                                   </div>
                                </div>
                           </div>
                       </div>
                         
                        <div class="tab-content clearfix" id="tab-5">
                            <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                     <a href="#faq-cat-5-sub-1" data-parent="#accordion-cat-4" data-toggle="collapse">
                                        <h4 class="panel-title">
                                        When can you collect my order?
                                        <span class="pull-right">
                                       <i class="fa fa-fw fa-plus-square"></i>
                                       </span>
                                       </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-1" class="panel-collapse collapse">
                                     <div class="panel-body">
					Collection and delivery times can differ, but we're typically available from 7am to 11pm, 7 days a week.
					<br>
					<br>
					    Want to check our availability? Order online today!
						
				     </div>
                                </div>
                           </div>
                            <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                     <a href="#faq-cat-5-sub-2" data-parent="#accordion-cat-4" data-toggle="collapse">
                                       <h4 class="panel-title">
                                          Can I schedule pickup and delivery at different locations?
                                          <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                          </span>
                                      </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-2" class="panel-collapse collapse">
                                     <div class="panel-body">
					Not at the moment. Currently pickup and delivery needs to be at the same location, but we'll add multi-location orders very soon.
				     </div>
                                </div>
                            </div>
                            <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a href="#faq-cat-5-sub-3" data-parent="#accordion-cat-4" data-toggle="collapse">
                                        <h4 class="panel-title">
                                          Where do I input the coupen code?
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-3" class="panel-collapse collapse">
                                     <div class="panel-body"> when you order online, please enter your coupen code on the checkout screen at the end of the order process.  </div>
                                </div>
                            </div>
                              <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a href="#faq-cat-5-sub-4" data-parent="#accordion-cat-4" data-toggle="collapse">
                                        <h4 class="panel-title">
                                           How long does it take for you to clean my clothes?
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-4" class="panel-collapse collapse">
                                     <div class="panel-body">
					You can choose a time slot that is most convenient for you! We turnaround all orders within 48-72hours, ready for delivery whenever you want. Dry cleaning can take 5days.
				     </div>
                                </div>
                            </div>
                              <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a href="#faq-cat-5-sub-5" data-parent="#accordion-cat-4" data-toggle="collapse">
                                        <h4 class="panel-title">
                                         Can I give you back my hangers, thin board, pins, covers from a previous order?
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-5" class="panel-collapse collapse">
                                     <div class="panel-body">
					Yes, of course! Please just hand them over to your theWashBox Agent on your next collection and we'll recycle them for you.
				     </div>
                                </div>
                            </div>
                              <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a href="#faq-cat-5-sub-6" data-parent="#accordion-cat-4" data-toggle="collapse">
                                        <h4 class="panel-title">
                                         Can I reschedule a collection or delivery?
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-6" class="panel-collapse collapse">
                                     <div class="panel-body">
					Yes, you can by contacting Customer Care at <a href="#">customercare@thewashbox.com.</a>
				     </div>
                                </div>
                            </div>
			       <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a href="#faq-cat-5-sub-7" data-parent="#accordion-cat-4" data-toggle="collapse">
                                        <h4 class="panel-title">
                                         Where can I find my order history?
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-7" class="panel-collapse collapse">
                                     <div class="panel-body">
					Your order history is available in the top right section, after you login your name displays in the header click the header for your details. Open theWashBox on your phone or tap the basket icon on the top right � that will show you any open or previous orders.
				     </div>
                                </div>
                            </div>
			       <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a href="#faq-cat-5-sub-8" data-parent="#accordion-cat-4" data-toggle="collapse">
                                        <h4 class="panel-title">
                                           I missed a scheduled collection/delivery, what do I do?
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-8" class="panel-collapse collapse">
                                     <div class="panel-body">
					Don�t panic, all you need to do is contact Customer Care at customercare@thewashbox.com to arrange a new time.
					<br>
					 Alternatively, we will try to contact you and arrange a new collection or delivery time for a period of 30 days. If you've not claimed your clothes within 90 days we reserve the right to give them to a registered charity of our choice.   
				     </div>
                                </div>
                            </div>
			      <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a href="#faq-cat-5-sub-9" data-parent="#accordion-cat-4" data-toggle="collapse">
                                        <h4 class="panel-title">
                                          Why is my collection/delivery slot greyed out?
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-9" class="fa fa-fw fa-plus-square">
                                     <div class="panel-body">
					That's because we're busy at those times and can't take any more orders, sorry! Please choose another available time and we'll see you then.  
				     </div>
                                </div>
                            </div>
			       <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a href="#faq-cat-5-sub-10" data-parent="#accordion-cat-4" data-toggle="collapse">
                                        <h4 class="panel-title">
                                         Are there any fabrics you don't clean?
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-10" class="panel-collapse collapse">
                                     <div class="panel-body">
					We don�t currently clean leather, suede, velvet or fur items. In the rare event that we receive your clothes and cannot clean them, we will notify you as soon as possible.  
				     </div>
                                </div>
                            </div>
			    <div class="panel panel-default panel-faq">
                                <div class="panel-heading">
                                    <a href="#faq-cat-5-sub-11" data-parent="#accordion-cat-4" data-toggle="collapse">
                                        <h4 class="panel-title">
                                        What are your customer care hours?
                                            <span class="pull-right">
                                               <i class="fa fa-fw fa-plus-square"></i>
                                            </span>
                                        </h4>
                                    </a>
                                </div>
                                <div id="faq-cat-5-sub-11" class="panel-collapse collapse">
                                     <div class="panel-body">
					We're here and happy to help from 7am to 11pm on weekdays and Sundays; 8am to 6pm on Saturdays. Please contact us by email at<a href="#">customercare@thewashbox.com.</a>
				     </div>
                                </div>
                            </div>   
                        </div>
                        <div class="tab-content clearfix" id="tab-6">
                        <div class="panel panel-default panel-faq">
                           <div class="panel-heading">
                               <a class="collapsed" href="#faq-cat-6-sub-1" data-parent="#accordion-cat-5" data-toggle="collapse" aria-expanded="false">
                                  <h4 class="panel-title">
                                      What if I am experiencing technical glitch?
                                     <span class="pull-right">
                                        <i class="fa fa-fw fa-plus-square"></i>
                                     </span>
                                 </h4>
                               </a>
                            </div>
                           <div id="faq-cat-6-sub-1" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                <div class="panel-body">
                                        Our engineers are hard at work improving the app and testing for bugs, but we aren�t perfect. If you are experiencing issues with the app, we would love to hear from you via phone
                                        <span class="skype_c2c_print_container notranslate">+91 8884000840</span>
                                        <span id="skype_c2c_container" class="skype_c2c_container notranslate" data-ismobile="false" data-isrtl="false" data-isfreecall="false" data-numbertype="paid" data-numbertocall="+918884000840" onclick="SkypeClick2Call.MenuInjectionHandler.makeCall(this, event)" onmouseout="SkypeClick2Call.MenuInjectionHandler.hideMenu(this, event)" onmouseover="SkypeClick2Call.MenuInjectionHandler.showMenu(this, event)" tabindex="-1" dir="ltr">
                                        or email (connect@theWashBox.in).
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default panel-faq">
                            <div class="panel-heading">
                                 <a class="" href="#faq-cat-6-sub-2" data-parent="#accordion-cat-5" data-toggle="collapse" aria-expanded="true">
                                    <h4 class="panel-title">
                                        What are all the delicacies involves in account creation?
                                        <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                        </span>
                                    </h4>
                                 </a>
                            </div>
                            <div id="faq-cat-6-sub-2" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                 <div class="panel-body">
                                   Sign Up's / Login are hassle free with theWashBox. We avoid that pain stacking process. Just like our service at single click, now you can sign up at just single click using your Google or Facebook accounts.
                                    <br>
                                    <br>
                                   If you don't have facebook or Google account,you can create your own account. 
                                 </div>
                            </div>
                      </div>
                         <div class="panel panel-default panel-faq">
                            <div class="panel-heading">
                                 <a class="" href="#faq-cat-6-sub-3" data-parent="#accordion-cat-5" data-toggle="collapse" aria-expanded="true">
                                    <h4 class="panel-title">
                                       How do I fix if I am having account issues or forgot password? 
                                        <span class="pull-right">
                                             <i class="fa fa-fw fa-plus-square"></i>
                                        </span>
                                    </h4>
                                 </a>
                            </div>
                            <div id="faq-cat-6-sub-3" class="panel-collapse collapse" aria-expanded="false" style="height: 0px;">
                                 <div class="panel-body">
                                      With TheWashBox hassle free model, this thought of question become void. 
                                 </div>
                            </div>
                        </div>
                    </div>
                          <div class="tab-content clearfix" id="tab-7">
                           
                     </div>
                     <div class="tab-content clearfix" id="tab-8">

                     </div>
	        </div>
            </div>
        </div>
    </div>
</div>
	
	</div>
	<script>
	    
	</script>