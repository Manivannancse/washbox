 <style>
    @media (max-width: 768px)
    {
        .tabs ul{
            width: 100% !important;
            min-height: 1px !important;
            padding-left: 15px !important;
            padding-right: 15px !important;
            position: relative !important;
            text-align: center !important;
        }
    }
    .otherOptions{
        background: none !important;
        cursor: pointer !important;
    }
    thead {
        background: #38A5DA;
        color: white;
    }
    table{
/*        box-shadow: 0 7px 9px -2px grey;
*/    }
/*.addarrow{
		   background-image: url(<?php echo site_url();?>application/assests/images/1_03.png);
}*/
 </style>
<!-- Content
        ============================================= -->
        <section style="background: #F2F2F2; padding: 43px ;">
		   <div class="container"  style=" background:white;padding: 43px ;box-shadow:2px 2px 17px -2px grey ">
                           <div class="slider-caption-center">
                                <h2 data-caption-animate="fadeInUp" class="howit">How Its Works</h2>
                                
                            </div>
            <div class="content-wrap">
             

		<div class="row clearfix bottommargin-lg common-height">
		   <div class="hidden-sm hidden-xs ">
				      <div style="float: right;padding-right:20%;display: inline;margin-bottom: -30px">
					<img src="<?php echo site_url();?>application/assests/images/1_03.png">		 
				      </div>
				      <div style="float: right;padding-right:33%;display: inline;margin-bottom: -30px">
					<img src="<?php echo site_url();?>application/assests/images/1_03.png">		 
				      </div>
				      <div style="float: right;padding-right:43%;display: inline;margin-bottom: -30px">
					<img src="<?php echo site_url();?>application/assests/images/1_03.png">		 
				      </div>
		   </div>
		   

		   <div class="hidden-md hidden-xs hidden-lg">
				      <div style="float: right;padding-right:35%;display: inline;margin-bottom: -33px">
					<img src="<?php echo site_url();?>application/assests/images/1_03.png">		 
				      </div>
		   </div>
                    <div class="col-md-3 col-sm-6 dark center col-padding">

                        <div class="">
			    <img class="addarrow" src="<?php echo site_url();?>application/assests/images/final/order.png">
			<div class="pickanddeliver1">
                            <a class="pickanddeliver drycl pricesmall"><div>Your Order</div></a>
			    <a class="pricesmall1 drycl">Order through mobile,tablet or Desktop</a>
			    
                        </div>
			</div>
                    </div>

                    <div class="col-md-3 col-sm-6 dark center col-padding">
                        <div>
			    <img class="" src="<?php echo site_url();?>application/assests/images/final/collect.png">
			<div class="pickanddeliver1">
			    <a class="pickanddeliver drycl pricesmall">We Collect</a><br>
			    <a class="pricesmall1 drycl">Choose a time and place that suit you</a>
                        </div>
			</div>
                    </div>

                    <div class="col-md-3 col-sm-6 dark center col-padding">
                        <div>
			    <img class="" src="<?php echo site_url();?>application/assests/images/final/wash.png">
			<div class="pickanddeliver1">
			    <a class="pickanddeliver drycl pricesmall">We Clean</a><br>
			    <a class="pricesmall1 drycl">Your clothes are given a high quality clean</a>
                        </div>
			</div>
                    </div>

                    <div class="col-md-3 col-sm-6 dark center col-padding">
                        <div>
			    <img class="" src="<?php echo site_url();?>application/assests/images/final/delivery.png">
			<div class="pickanddeliver1">
			    <a class="pickanddeliver drycl pricesmall">We Deliver</a><br>
			    <a class="pricesmall1 drycl">We'll deliver back to you anytime,anyware</a>
			</div>
			</div>
                    </div>

		   
		   <div class="hidden-sm hidden-xs">	
				      <div style="float: right;padding-right:20%;display: inline;margin-bottom: -30px">
					<img src="<?php echo site_url();?>application/assests/images/1_19.png">		 
				      </div>
				      <div style="float: right;padding-right:33%;display: inline;margin-bottom: -30px">
					<img src="<?php echo site_url();?>application/assests/images/1_19.png">		 
				      </div>
				      <div style="float: right;padding-right:43%;display: inline;margin-bottom: -30px">
					<img src="<?php echo site_url();?>application/assests/images/1_19.png">		 
				      </div>
		   </div>
		   <div class="hidden-md hidden-xs hidden-lg">
				      <div style="float: right;padding-right:35%;display: inline;margin-bottom: -30px">
					<img src="<?php echo site_url();?>application/assests/images/reverse_arrow.gif">		 
				      </div>
		   </div>
		   <div class="hidden-md hidden-xs hidden-lg">
				      <div style="position: absolute;top: 34%;left: 100%">
					<img src="<?php echo site_url();?>application/assests/images/right_arrow.gif">		 
				      </div>
		   </div>
		   <div class="hidden-md hidden-sm hidden-lg">
				      <div style="position: absolute;top: 11%;">
					<img src="<?php echo site_url();?>application/assests/images/top-left_arrow.gif">		 
				      </div>
		   </div>
		   <div class="hidden-md hidden-sm hidden-lg">
				      <div style="position: absolute;top: 34%;">
					<img src="<?php echo site_url();?>application/assests/images/top-left_arrow.gif">		 
				      </div>
		   </div>
		   <div class="hidden-md hidden-sm hidden-lg">
				      <div style="position: absolute;top: 59%;">
					<img src="<?php echo site_url();?>application/assests/images/top-left_arrow.gif">		 
				      </div>
		   </div>
		   <div class="hidden-md hidden-sm hidden-lg">
				      <div style="position: absolute;top: 11%;left: 95%">
					<img src="<?php echo site_url();?>application/assests/images/right_arrow.gif">		 
				      </div>
		   </div>
		   <div class="hidden-md hidden-sm hidden-lg">
				      <div style="position: absolute;top: 34%;left: 95%">
					<img src="<?php echo site_url();?>application/assests/images/right_arrow.gif">		 
				      </div>
		   </div>
		   <div class="hidden-md hidden-sm hidden-lg">
				      <div style="position: absolute;top: 59%;left: 95%">
					<img src="<?php echo site_url();?>application/assests/images/right_arrow.gif">		 
				      </div>
		   </div>
	        </div>
             <div class="clear"></div>
	    </div>
	</section>
	