<table width="100%" cellspacing="0" cellpadding="0" border="0">
<tbody>
<tr>
<td bgcolor="#f7f7f9">
<table width="" cellspacing="0" cellpadding="0" border="0" bgcolor="#68c1ec" align="center" style="background:#68c1ec">
<tbody>
<tr>
<td valign="top">
<a href="#151140d8c6609631_1502e0a0d2dc3e62_146a39c5dc1b770c_140839483da7d746_">
<img class="CToWUd" border="0" alt="MyWash - Clean clothes, at the tap of a button" src="https://ci3.googleusercontent.com/proxy/5xn3nO_qUbUDHWhBqtGw9Piqk7IruNiS4710i3dkdYnwqksZVOKWkBFIMieESoPouTZ83gTDrmYeht4SSo-YQevFxVEecTASgqMwx4C8hGj5vCdsTQ=s0-d-e1-ft#https://c4.staticflickr.com/4/3934/15349502807_dd66d0d89c_z.jpg" style="margin:0px;padding:0px;display:block">
</a>
</td>
</tr>
</tbody>
</table>
<table width="581" cellspacing="0" cellpadding="0" border="0" bgcolor="#f7f7f9" align="center" style="border-bottom:1px solid #e1e1e1;margin-bottom:30px">
<tbody>
<tr>
<td valign="top" style="padding:0px 13px 10px 14px;font-family:Helvetica,Arial,sans-serif">
<table width="100%" cellspacing="0" cellpadding="0" style="background:#f7f7f9;padding:15px">
<tbody>
<tr>
<td style="padding-bottom:10px">
<h2 style="font-size:22px;font-weight:bold;color:#666666;font-family:'Myriad Pro','Arial',sans-serif;font-weight:300">

                          Welcome <?php echo $data["first_name"]; ?>,
                    
</td>
</tr>
<tr>
<td style="color:#666666;font-size:16px;padding-bottom:17px;font-family:'Myriad Pro','Arial',sans-serif;font-weight:300;font-weight:2"> Thank you for signing up with MyWash and Welcome aboard! Schedule our service, and we shall Pick up, Wash, Iron and Deliver your clothes, all with utmost care. Can't wait to serve you! </td>
</tr>
<tr>
<td style="color:#666666;font-size:16px;padding-bottom:17px;font-family:'Myriad Pro','Arial',sans-serif;font-weight:300;font-weight:2">
For any queries or feedback, please write to us at
<a target="_blank" href="mailto:support@mywash.com">support@mywash.com</a>
</td>
</tr>
<tr>
<td style="color:#666666;font-size:16px;padding-bottom:17px;font-family:'Myriad Pro','Arial',sans-serif;font-weight:300;font-weight:2">
Regards,
<br>
Team MyWash
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<table width="581" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse;height:30px">
<tbody>
<tr>
<td style="text-align:center;font-size:18px;color:#666666;font-size:16px;padding-bottom:17px;font-family:'Myriad Pro','Arial',sans-serif;font-weight:300"> Follow Us for Offers and Updates </td>
</tr>
</tbody>
</table>
<table width="100" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse;height:70px;text-align:center;border-bottom:1px solid #e1e1e1;margin-bottom:30px">
<tbody>
<tr>
<td width="30">
<a target="_blank" style="text-decoration:none" href="https://www.facebook.com/mywashapp">
<img class="CToWUd" width="30" height="30" border="0" style="text-decoration:none;display:block;outline:none" src="https://ci4.googleusercontent.com/proxy/Wr9kpmYJkFO8fpqGcWpURewi6R41kK7xAnsqKxrLGACkNVBpHk6Hh50zG9hGOQ0vg8ft3y5W32ReM0UPcFx_buVAHA_KORUzmJBOsRUkn3sKTqyZlD2LDK6I2clTZNjM=s0-d-e1-ft#http://www.ala.org/news/sites/ala.org.news/files/content/facebook-icon.png">
</a>
</td>
<td width="30">
<a target="_blank" style="text-decoration:none" href="https://twitter.com/mywashapp">
<img class="CToWUd" width="30" height="30" border="0" style="text-decoration:none;display:block;outline:none" src="https://ci3.googleusercontent.com/proxy/oJNjE1CQCyxU5yeltC7RBHW-Q6oUOlw3xuyunHboGhwE_FEJKPLkMw-nqGrnlxkVYeiXWpaXqub9QUNcS2ODESyI9WBs4EGCAGD0q10Uk3L8OuJXMNZmzEobCZPY2v8zqJUSBQ=s0-d-e1-ft#http://www.phonodelsol.com/wp-content/themes/SCRN/images/icn-twitter-intro.png">
</a>
</td>
</tr>
</tbody>
</table>
<span class="HOEnZb">
<font color="#888888"> </font>
</span>
<span class="HOEnZb">
<font color="#888888"> </font>
</span>
<span class="HOEnZb">
<font color="#888888"> </font>
</span>
<table width="581" cellspacing="0" cellpadding="0" border="0" align="center" style="border-collapse:collapse;height:30px">
<tbody>
<tr>
<td style="text-align:center;font-size:18px;color:#666666;font-size:16px;padding-bottom:17px;font-family:'Myriad Pro','Arial',sans-serif;font-weight:300">
<small>� MyWash Technologies Pvt Limited, Bangalore</small>
<span class="HOEnZb">
<font color="#888888"> </font>
</span>
</td>
</tr>
</tbody>
</table>
<span class="HOEnZb">
<font color="#888888"> </font>
</span>
</td>
</tr>
</tbody>
</table>